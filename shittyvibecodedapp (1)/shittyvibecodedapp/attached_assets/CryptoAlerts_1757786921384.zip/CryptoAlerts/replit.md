# QuestTracker - Telegram Mini App

## Overview

QuestTracker is a habit-tracking and task management application designed as a Telegram Mini App. It gamifies personal productivity by implementing a quest-based system where users can create tasks, complete them for XP rewards, and level up their character while developing various skill attributes. The app features a comprehensive progression system with levels, ranks, and skill trees, making daily productivity engaging and rewarding.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript in a Vite development environment
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom design system featuring dark theme and gaming-inspired aesthetics
- **State Management**: TanStack Query for server state management with optimistic updates
- **Routing**: Wouter for lightweight client-side routing
- **Mobile-First Design**: Responsive components with mobile breakpoint detection

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with structured JSON responses
- **Error Handling**: Centralized middleware with proper HTTP status codes
- **Development Setup**: Hot reload with Vite middleware integration

### Data Storage Solutions
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Database**: PostgreSQL with UUID primary keys and timestamps
- **Schema Management**: Code-first approach with Drizzle migrations
- **Development Storage**: In-memory storage adapter for rapid prototyping

### Authentication and Authorization
- **User Management**: Simple credential-based system with username/password
- **Session Handling**: Express session management with PostgreSQL session store
- **Admin Mode**: Special privilege escalation for advanced features
- **Security**: Password hashing and secure session cookies

### Core Data Models
- **Users**: Level progression, XP tracking, and skill attributes (Physique, Mental, Success, Social, Skills)
- **Quest Groups**: Categorized task organization with custom icons
- **Quests**: Tasks with difficulty ranks (E-SSS), XP rewards, attribute bonuses, and optional deadlines
- **Archived Quests**: 24-hour rollback system for completed quests
- **Notes**: Personal note-taking with optional encryption support

### Gaming Systems
- **Level Progression**: XP-based leveling (800 XP per level) with visual progress indicators
- **Rank System**: Global ranks from E to SSS based on character level
- **Attribute System**: Five-skill radar chart with real-time visualization
- **Quest Ranking**: Eight difficulty tiers affecting visual presentation and reward suggestions

### User Interface Components
- **Tab Navigation**: Five main sections (Quests, Attributes, Archive, Notes, Settings)
- **Quest Management**: Card-based interface with swipe actions and modal creation forms
- **Progress Visualization**: Animated progress bars, radar charts, and level-up notifications
- **Responsive Design**: Mobile-optimized with touch-friendly interactions

## External Dependencies

### UI and Styling
- **@radix-ui/react-***: Comprehensive accessible component primitives
- **tailwindcss**: Utility-first CSS framework with custom design tokens
- **class-variance-authority**: Component variant management
- **lucide-react**: Consistent icon system

### Data Management
- **@tanstack/react-query**: Server state synchronization and caching
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-zod**: Runtime schema validation integration

### Development Tools
- **vite**: Fast development server and build tool
- **typescript**: Static type checking and enhanced developer experience
- **@replit/vite-plugin-***: Replit-specific development enhancements

### Utilities
- **date-fns**: Date manipulation and formatting
- **zod**: Runtime type validation and schema parsing
- **wouter**: Lightweight client-side routing
- **react-hook-form**: Form state management and validation