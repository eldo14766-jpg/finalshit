import { type User, type InsertUser, type Quest, type InsertQuest, type QuestGroup, type InsertQuestGroup, type ArchivedQuest, type InsertArchivedQuest, type Note, type InsertNote } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser & {id?: string}): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Quest Groups
  getQuestGroups(userId: string): Promise<QuestGroup[]>;
  createQuestGroup(group: InsertQuestGroup): Promise<QuestGroup>;
  updateQuestGroup(id: string, updates: Partial<QuestGroup>): Promise<QuestGroup | undefined>;
  deleteQuestGroup(id: string): Promise<boolean>;

  // Quests
  getQuests(userId: string): Promise<Quest[]>;
  getQuest(id: string): Promise<Quest | undefined>;
  createQuest(quest: InsertQuest): Promise<Quest>;
  updateQuest(id: string, updates: Partial<Quest>): Promise<Quest | undefined>;
  deleteQuest(id: string): Promise<boolean>;
  completeQuest(id: string): Promise<Quest | undefined>;

  // Archived Quests
  getArchivedQuests(userId: string): Promise<ArchivedQuest[]>;
  getArchivedQuest(id: string): Promise<ArchivedQuest | undefined>;
  createArchivedQuest(quest: InsertArchivedQuest): Promise<ArchivedQuest>;
  deleteArchivedQuest(id: string): Promise<boolean>;
  cleanExpiredArchivedQuests(): Promise<void>;

  // Notes
  getNotes(userId: string): Promise<Note[]>;
  getNote(id: string): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: string, updates: Partial<Note>): Promise<Note | undefined>;
  deleteNote(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private questGroups: Map<string, QuestGroup>;
  private quests: Map<string, Quest>;
  private archivedQuests: Map<string, ArchivedQuest>;
  private notes: Map<string, Note>;

  constructor() {
    this.users = new Map();
    this.questGroups = new Map();
    this.quests = new Map();
    this.archivedQuests = new Map();
    this.notes = new Map();

    // Start cleanup interval for expired archived quests
    setInterval(() => {
      this.cleanExpiredArchivedQuests();
    }, 60000); // Check every minute
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser & {id?: string}): Promise<User> {
    const id = insertUser.id || randomUUID();
    const user: User = { 
      username: insertUser.username,
      password: insertUser.password,
      level: insertUser.level || 1,
      totalXP: insertUser.totalXP || 0,
      currentXP: insertUser.currentXP || 0,
      globalRank: insertUser.globalRank || "E",
      physique: insertUser.physique || 0,
      mental: insertUser.mental || 0,
      success: insertUser.success || 0,
      social: insertUser.social || 0,
      skills: insertUser.skills || 0,
      adminMode: insertUser.adminMode || false,
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Quest Groups
  async getQuestGroups(userId: string): Promise<QuestGroup[]> {
    return Array.from(this.questGroups.values()).filter(
      (group) => group.userId === userId
    );
  }

  async createQuestGroup(insertGroup: InsertQuestGroup): Promise<QuestGroup> {
    const id = randomUUID();
    const group: QuestGroup = { ...insertGroup, id };
    this.questGroups.set(id, group);
    return group;
  }

  async updateQuestGroup(id: string, updates: Partial<QuestGroup>): Promise<QuestGroup | undefined> {
    const group = this.questGroups.get(id);
    if (!group) return undefined;
    
    const updatedGroup = { ...group, ...updates };
    this.questGroups.set(id, updatedGroup);
    return updatedGroup;
  }

  async deleteQuestGroup(id: string): Promise<boolean> {
    return this.questGroups.delete(id);
  }

  // Quests
  async getQuests(userId: string): Promise<Quest[]> {
    return Array.from(this.quests.values()).filter(
      (quest) => quest.userId === userId && !quest.isCompleted
    );
  }

  async getQuest(id: string): Promise<Quest | undefined> {
    return this.quests.get(id);
  }

  async createQuest(insertQuest: InsertQuest): Promise<Quest> {
    const id = randomUUID();
    const quest: Quest = { 
      name: insertQuest.name,
      description: insertQuest.description || null,
      groupId: insertQuest.groupId || null,
      rank: insertQuest.rank,
      xpReward: insertQuest.xpReward,
      attributeRewards: insertQuest.attributeRewards as any || null,
      deadline: insertQuest.deadline || null,
      repeatType: insertQuest.repeatType || null,
      isCompleted: insertQuest.isCompleted || false,
      userId: insertQuest.userId,
      id,
      createdAt: new Date()
    };
    this.quests.set(id, quest);
    return quest;
  }

  async updateQuest(id: string, updates: Partial<Quest>): Promise<Quest | undefined> {
    const quest = this.quests.get(id);
    if (!quest) return undefined;
    
    const updatedQuest = { ...quest, ...updates };
    this.quests.set(id, updatedQuest);
    return updatedQuest;
  }

  async deleteQuest(id: string): Promise<boolean> {
    return this.quests.delete(id);
  }

  async completeQuest(id: string): Promise<Quest | undefined> {
    const quest = this.quests.get(id);
    if (!quest) return undefined;
    
    const completedQuest = { ...quest, isCompleted: true };
    this.quests.set(id, completedQuest);
    return completedQuest;
  }

  // Archived Quests
  async getArchivedQuests(userId: string): Promise<ArchivedQuest[]> {
    return Array.from(this.archivedQuests.values()).filter(
      (quest) => quest.userId === userId
    );
  }

  async getArchivedQuest(id: string): Promise<ArchivedQuest | undefined> {
    return this.archivedQuests.get(id);
  }

  async createArchivedQuest(insertArchived: InsertArchivedQuest): Promise<ArchivedQuest> {
    const id = randomUUID();
    const archivedQuest: ArchivedQuest = { 
      originalQuestId: insertArchived.originalQuestId,
      name: insertArchived.name,
      description: insertArchived.description || null,
      rank: insertArchived.rank,
      xpReward: insertArchived.xpReward,
      attributeRewards: insertArchived.attributeRewards as any || null,
      userId: insertArchived.userId,
      id,
      completedAt: new Date(),
      expiresAt: insertArchived.expiresAt
    };
    this.archivedQuests.set(id, archivedQuest);
    return archivedQuest;
  }

  async deleteArchivedQuest(id: string): Promise<boolean> {
    return this.archivedQuests.delete(id);
  }

  async cleanExpiredArchivedQuests(): Promise<void> {
    const now = new Date();
    const entries = Array.from(this.archivedQuests.entries());
    for (const [id, quest] of entries) {
      if (quest.expiresAt < now) {
        this.archivedQuests.delete(id);
      }
    }
  }

  // Notes
  async getNotes(userId: string): Promise<Note[]> {
    return Array.from(this.notes.values()).filter(
      (note) => note.userId === userId
    );
  }

  async getNote(id: string): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = randomUUID();
    const note: Note = { 
      title: insertNote.title,
      content: insertNote.content,
      isEncrypted: insertNote.isEncrypted || false,
      encryptedData: insertNote.encryptedData || null,
      userId: insertNote.userId,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.notes.set(id, note);
    return note;
  }

  async updateNote(id: string, updates: Partial<Note>): Promise<Note | undefined> {
    const note = this.notes.get(id);
    if (!note) return undefined;
    
    const updatedNote = { 
      ...note, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: string): Promise<boolean> {
    return this.notes.delete(id);
  }
}

export const storage = new MemStorage();
