import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuestSchema, insertQuestGroupSchema, insertNoteSchema, insertArchivedQuestSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Users
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const updates = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      console.log("Creating user with data:", userData);
      const user = await storage.createUser(userData);
      console.log("User created with ID:", user.id);
      res.status(201).json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Quest Groups
  app.get("/api/quest-groups/:userId", async (req, res) => {
    try {
      const groups = await storage.getQuestGroups(req.params.userId);
      res.json(groups);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/quest-groups", async (req, res) => {
    try {
      const groupData = insertQuestGroupSchema.parse(req.body);
      const group = await storage.createQuestGroup(groupData);
      res.status(201).json(group);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid group data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Quests
  app.get("/api/quests/:userId", async (req, res) => {
    try {
      const quests = await storage.getQuests(req.params.userId);
      res.json(quests);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/quests", async (req, res) => {
    try {
      const questData = insertQuestSchema.parse(req.body);
      const quest = await storage.createQuest(questData);
      res.status(201).json(quest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid quest data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/quests/:id", async (req, res) => {
    try {
      const updates = req.body;
      const quest = await storage.updateQuest(req.params.id, updates);
      if (!quest) {
        return res.status(404).json({ message: "Quest not found" });
      }
      res.json(quest);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/quests/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteQuest(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Quest not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/quests/:id/complete", async (req, res) => {
    try {
      const quest = await storage.getQuest(req.params.id);
      if (!quest) {
        return res.status(404).json({ message: "Quest not found" });
      }

      // Complete quest and update user stats
      const completedQuest = await storage.completeQuest(req.params.id);
      const user = await storage.getUser(quest.userId);
      
      if (user && completedQuest) {
        // Calculate new XP and level
        const newTotalXP = user.totalXP + quest.xpReward;
        const newLevel = Math.floor(newTotalXP / 800) + 1;
        const newCurrentXP = newTotalXP % 800;
        
        // Calculate global rank
        const globalRank = calculateGlobalRank(newLevel);
        
        // Update attributes
        const attributes = quest.attributeRewards || {};
        const updatedUser = await storage.updateUser(quest.userId, {
          totalXP: newTotalXP,
          currentXP: newCurrentXP,
          level: newLevel,
          globalRank,
          physique: user.physique + (attributes.physique || 0),
          mental: user.mental + (attributes.mental || 0),
          success: user.success + (attributes.success || 0),
          social: user.social + (attributes.social || 0),
          skills: user.skills + (attributes.skills || 0),
        });

        // Archive the quest
        await storage.createArchivedQuest({
          originalQuestId: quest.id,
          name: quest.name,
          description: quest.description,
          rank: quest.rank,
          xpReward: quest.xpReward,
          attributeRewards: quest.attributeRewards,
          userId: quest.userId,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        });

        res.json({ quest: completedQuest, user: updatedUser });
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Archived Quests
  app.get("/api/archived-quests/:userId", async (req, res) => {
    try {
      const archivedQuests = await storage.getArchivedQuests(req.params.userId);
      res.json(archivedQuests);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/archived-quests/:id/undo", async (req, res) => {
    try {
      const archivedQuest = await storage.getArchivedQuest(req.params.id);
      if (!archivedQuest) {
        return res.status(404).json({ message: "Archived quest not found" });
      }

      const user = await storage.getUser(archivedQuest.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Reverse XP and attribute changes
      const newTotalXP = Math.max(0, user.totalXP - archivedQuest.xpReward);
      const newLevel = Math.floor(newTotalXP / 800) + 1;
      const newCurrentXP = newTotalXP % 800;
      const globalRank = calculateGlobalRank(newLevel);
      
      const attributes = archivedQuest.attributeRewards || {};
      const updatedUser = await storage.updateUser(archivedQuest.userId, {
        totalXP: newTotalXP,
        currentXP: newCurrentXP,
        level: newLevel,
        globalRank,
        physique: Math.max(0, user.physique - (attributes.physique || 0)),
        mental: Math.max(0, user.mental - (attributes.mental || 0)),
        success: Math.max(0, user.success - (attributes.success || 0)),
        social: Math.max(0, user.social - (attributes.social || 0)),
        skills: Math.max(0, user.skills - (attributes.skills || 0)),
      });

      // Restore quest as active
      const restoredQuest = await storage.createQuest({
        name: archivedQuest.name,
        description: archivedQuest.description,
        rank: archivedQuest.rank,
        xpReward: archivedQuest.xpReward,
        attributeRewards: archivedQuest.attributeRewards,
        userId: archivedQuest.userId,
        groupId: null,
        deadline: null,
        repeatType: null,
        isCompleted: false,
      });

      // Delete from archive
      await storage.deleteArchivedQuest(req.params.id);

      res.json({ quest: restoredQuest, user: updatedUser });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Notes
  app.get("/api/notes/:userId", async (req, res) => {
    try {
      const notes = await storage.getNotes(req.params.userId);
      res.json(notes);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/notes", async (req, res) => {
    try {
      const noteData = insertNoteSchema.parse(req.body);
      const note = await storage.createNote(noteData);
      res.status(201).json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid note data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/notes/:id", async (req, res) => {
    try {
      const updates = req.body;
      const note = await storage.updateNote(req.params.id, updates);
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/notes/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteNote(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Note not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function calculateGlobalRank(level: number): string {
  if (level >= 401) return "SSS";
  if (level >= 251) return "SS";
  if (level >= 151) return "S";
  if (level >= 101) return "A";
  if (level >= 61) return "B";
  if (level >= 31) return "C";
  if (level >= 11) return "D";
  return "E";
}
