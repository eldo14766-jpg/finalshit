import { useState, useCallback } from "react";

export function useAdminMode() {
  const [isAdminMode, setIsAdminMode] = useState(false);

  const activateAdminMode = useCallback(() => {
    setIsAdminMode(true);
    console.log("🔧 Admin Mode Activated");
    console.log("Features available:");
    console.log("- Long-tap any text element to edit");
    console.log("- Edit numeric values directly");
    console.log("- Access debug data in console");
    
    // Enable global editing features
    document.body.dataset.adminMode = "true";
    
    // Add long-tap listeners for text editing
    document.addEventListener("contextmenu", handleLongTap);
  }, []);

  const deactivateAdminMode = useCallback(() => {
    setIsAdminMode(false);
    console.log("🔒 Admin Mode Deactivated");
    
    // Disable global editing features
    delete document.body.dataset.adminMode;
    
    // Remove long-tap listeners
    document.removeEventListener("contextmenu", handleLongTap);
  }, []);

  const handleLongTap = useCallback((e: MouseEvent) => {
    if (!isAdminMode) return;
    
    e.preventDefault();
    const target = e.target as HTMLElement;
    
    // Only allow editing of text content
    if (target.textContent && target.textContent.trim()) {
      const newValue = prompt("Edit text:", target.textContent);
      if (newValue !== null) {
        target.textContent = newValue;
      }
    }
  }, [isAdminMode]);

  return {
    isAdminMode,
    activateAdminMode,
    deactivateAdminMode,
  };
}
