import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { User, Quest, QuestGroup, ArchivedQuest, Note } from "@shared/schema";
import QuestCard from "@/components/quest-card";
import NewQuestModal from "@/components/new-quest-modal";
import AttributesTab from "@/components/attributes-tab";
import ArchiveTab from "@/components/archive-tab";
import NotesTab from "@/components/notes-tab";
import SettingsTab from "@/components/settings-tab";
import LevelUpNotification from "@/components/level-up-notification";
import PasswordModal from "@/components/password-modal";
import { useAdminMode } from "@/hooks/use-admin-mode";
import { calculateLevel, calculateGlobalRank } from "@/lib/level-utils";
import { Plus, Sword, BarChart3, Archive, Book, Settings } from "lucide-react";

const DEFAULT_USER_ID = "default-user";

export default function Home() {
  const [activeTab, setActiveTab] = useState("quests");
  const [isNewQuestModalOpen, setIsNewQuestModalOpen] = useState(false);
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [newLevel, setNewLevel] = useState(0);
  const queryClient = useQueryClient();
  const { isAdminMode } = useAdminMode();

  // Initialize default user
  const initUser = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/users", {
        id: DEFAULT_USER_ID,
        username: "QuestMaster",
        password: "default",
        level: 1,
        totalXP: 0,
        currentXP: 0,
        globalRank: "E",
        physique: 0,
        mental: 0,
        success: 0,
        social: 0,
        skills: 0,
        adminMode: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", DEFAULT_USER_ID] });
    },
  });

  // Create default quest groups
  const initGroups = useMutation({
    mutationFn: async () => {
      const groups = [
        { name: "Fitness & Health", icon: "🏋️", userId: DEFAULT_USER_ID },
        { name: "Work & Career", icon: "💼", userId: DEFAULT_USER_ID },
        { name: "Learning", icon: "📚", userId: DEFAULT_USER_ID },
        { name: "Personal Development", icon: "🧘", userId: DEFAULT_USER_ID },
        { name: "Social", icon: "👥", userId: DEFAULT_USER_ID },
        { name: "Creative", icon: "🎨", userId: DEFAULT_USER_ID },
      ];
      
      for (const group of groups) {
        await apiRequest("POST", "/api/quest-groups", group);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quest-groups", DEFAULT_USER_ID] });
    },
  });

  // Initialize app on first load
  useEffect(() => {
    const initialize = async () => {
      try {
        await initUser.mutateAsync();
        await initGroups.mutateAsync();
      } catch (error) {
        console.log("User might already exist, continuing...");
      }
    };
    initialize();
  }, []);

  // Fetch user data
  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", DEFAULT_USER_ID],
    enabled: true,
  });

  // Fetch quest groups
  const { data: questGroups = [] } = useQuery<QuestGroup[]>({
    queryKey: ["/api/quest-groups", DEFAULT_USER_ID],
    enabled: true,
  });

  // Fetch active quests
  const { data: quests = [] } = useQuery<Quest[]>({
    queryKey: ["/api/quests", DEFAULT_USER_ID],
    enabled: true,
  });

  // Fetch archived quests
  const { data: archivedQuests = [] } = useQuery<ArchivedQuest[]>({
    queryKey: ["/api/archived-quests", DEFAULT_USER_ID],
    enabled: true,
  });

  // Fetch notes
  const { data: notes = [] } = useQuery<Note[]>({
    queryKey: ["/api/notes", DEFAULT_USER_ID],
    enabled: true,
  });

  // Complete quest mutation
  const completeQuest = useMutation({
    mutationFn: async (questId: string) => {
      return apiRequest("POST", `/api/quests/${questId}/complete`, {});
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests", DEFAULT_USER_ID] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", DEFAULT_USER_ID] });
      queryClient.invalidateQueries({ queryKey: ["/api/archived-quests", DEFAULT_USER_ID] });
      
      // Check for level up
      if (data.user && user && data.user.level > user.level) {
        setNewLevel(data.user.level);
        setShowLevelUp(true);
        setTimeout(() => setShowLevelUp(false), 3000);
      }
    },
  });

  // Group quests by their groups
  const questsByGroup = quests.reduce((acc, quest) => {
    const groupId = quest.groupId || "ungrouped";
    if (!acc[groupId]) acc[groupId] = [];
    acc[groupId].push(quest);
    return acc;
  }, {} as Record<string, Quest[]>);

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Initializing QuestTracker...</p>
        </div>
      </div>
    );
  }

  const xpProgress = ((user.currentXP || 0) / 800) * 100;

  return (
    <div className="max-w-md mx-auto bg-background min-h-screen relative overflow-hidden" data-testid="app-container">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="p-4">
          {/* Player Level & Rank */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className={`rank-badge rank-${user.globalRank?.toLowerCase()} rounded-lg px-3 py-1 font-gaming font-bold text-white text-sm animate-glow`}>
                {user.globalRank}
              </div>
              <div className="font-gaming font-bold text-2xl text-foreground">
                Lv. <span className="text-primary" data-testid="user-level">{user.level}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground" data-testid="total-xp">{user.totalXP} XP</div>
              <div className="text-xs text-muted-foreground">QuestTracker</div>
            </div>
          </div>

          {/* XP Progress Bar */}
          <div className="relative">
            <div className="h-3 bg-secondary rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-500 ease-out" 
                style={{ width: `${xpProgress}%` }}
                data-testid="xp-progress-bar"
              />
            </div>
            <div className="flex justify-between items-center mt-1">
              <span className="text-xs text-muted-foreground" data-testid="current-xp">{user.currentXP}</span>
              <span className="text-xs font-gaming text-primary">800 XP</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-20" data-testid="main-content">
        {/* Quests Tab */}
        {activeTab === "quests" && (
          <div className="p-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold" data-testid="active-quests-title">Active Quests</h2>
              <button 
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
                onClick={() => setIsNewQuestModalOpen(true)}
                data-testid="button-new-quest"
              >
                <Plus className="w-4 h-4" />
                New Quest
              </button>
            </div>

            {/* Quest Groups */}
            {Object.entries(questsByGroup).map(([groupId, groupQuests]) => {
              const group = questGroups.find(g => g.id === groupId);
              const groupName = group ? group.name : "Ungrouped";
              const groupIcon = group ? group.icon : "📝";
              
              return (
                <div key={groupId} className="mb-8">
                  <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center gap-2" data-testid={`group-${groupId}`}>
                    <span>{groupIcon}</span>
                    <span>{groupName}</span>
                  </h3>
                  
                  <div className="space-y-3">
                    {groupQuests.map((quest) => (
                      <QuestCard 
                        key={quest.id} 
                        quest={quest} 
                        onComplete={() => completeQuest.mutate(quest.id)}
                        isCompleting={completeQuest.isPending}
                      />
                    ))}
                  </div>
                </div>
              );
            })}

            {quests.length === 0 && (
              <div className="text-center py-12" data-testid="empty-quests">
                <Sword className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">No Active Quests</h3>
                <p className="text-muted-foreground mb-4">Create your first quest to start your adventure!</p>
                <button 
                  className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 rounded-lg"
                  onClick={() => setIsNewQuestModalOpen(true)}
                  data-testid="button-first-quest"
                >
                  Create First Quest
                </button>
              </div>
            )}
          </div>
        )}

        {/* Attributes Tab */}
        {activeTab === "attributes" && (
          <AttributesTab user={user} />
        )}

        {/* Archive Tab */}
        {activeTab === "archive" && (
          <ArchiveTab archivedQuests={archivedQuests} />
        )}

        {/* Notes Tab */}
        {activeTab === "notes" && (
          <NotesTab notes={notes} userId={DEFAULT_USER_ID} />
        )}

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <SettingsTab user={user} />
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-card/95 backdrop-blur-sm border-t border-border" data-testid="bottom-navigation">
        <div className="flex items-center justify-around py-2">
          {[
            { id: "quests", icon: Sword, label: "Quests" },
            { id: "attributes", icon: BarChart3, label: "Stats" },
            { id: "archive", icon: Archive, label: "Archive" },
            { id: "notes", icon: Book, label: "Journal" },
            { id: "settings", icon: Settings, label: "Settings" },
          ].map(({ id, icon: Icon, label }) => (
            <button 
              key={id}
              className={`nav-item p-3 rounded-lg transition-colors hover:bg-secondary/50 ${
                activeTab === id ? "active" : ""
              }`}
              onClick={() => setActiveTab(id)}
              data-testid={`nav-${id}`}
            >
              <Icon className={`text-lg mb-1 block ${
                activeTab === id ? "text-primary" : "text-muted-foreground"
              }`} />
              <span className={`text-xs ${
                activeTab === id ? "text-primary" : "text-muted-foreground"
              }`}>{label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Modals */}
      <NewQuestModal 
        isOpen={isNewQuestModalOpen}
        onClose={() => setIsNewQuestModalOpen(false)}
        questGroups={questGroups}
        userId={DEFAULT_USER_ID}
      />

      <PasswordModal />

      {/* Level Up Notification */}
      <LevelUpNotification 
        isVisible={showLevelUp}
        newLevel={newLevel}
      />
    </div>
  );
}
