import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import RadarChart from "./radar-chart";
import { Minus, Plus, Dumbbell, Brain, Trophy, Users, ServerCog } from "lucide-react";

interface AttributesTabProps {
  user: User;
}

const attributeIcons = {
  physique: Dumbbell,
  mental: Brain,
  success: Trophy,
  social: Users,
  skills: ServerCog,
};

const attributeColors = {
  physique: "red",
  mental: "purple",
  success: "yellow",
  social: "blue",
  skills: "green",
};

export default function AttributesTab({ user }: AttributesTabProps) {
  const queryClient = useQueryClient();

  const updateAttribute = useMutation({
    mutationFn: async ({ attribute, value }: { attribute: string; value: number }) => {
      return apiRequest("PUT", `/api/users/${user.id}`, {
        [attribute]: Math.max(0, value),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user.id] });
    },
  });

  const handleAttributeChange = (attribute: string, delta: number) => {
    const currentValue = user[attribute as keyof User] as number;
    updateAttribute.mutate({ attribute, value: currentValue + delta });
  };

  const getAttributeProgress = (value: number) => {
    // Show progress relative to max visible range (e.g., 250)
    return Math.min(100, (value / 250) * 100);
  };

  const attributes = [
    { key: "physique", name: "Physique", value: user.physique },
    { key: "mental", name: "Mental", value: user.mental },
    { key: "success", name: "Success", value: user.success },
    { key: "social", name: "Social", value: user.social },
    { key: "skills", name: "Skills", value: user.skills },
  ];

  return (
    <div className="p-4" data-testid="attributes-tab">
      <h2 className="text-xl font-bold mb-6">Attributes</h2>
      
      {/* Radar Chart */}
      <div className="bg-card border border-border rounded-lg p-6 mb-6">
        <h3 className="text-lg font-medium mb-4 text-center">Skills Overview</h3>
        <div className="flex justify-center">
          <RadarChart 
            data={attributes.map(attr => ({ 
              name: attr.name, 
              value: attr.value 
            }))}
          />
        </div>
      </div>

      {/* Attribute List */}
      <div className="space-y-4">
        {attributes.map((attribute) => {
          const Icon = attributeIcons[attribute.key as keyof typeof attributeIcons];
          const color = attributeColors[attribute.key as keyof typeof attributeColors];
          
          return (
            <div key={attribute.key} className="bg-card border border-border rounded-lg p-4" data-testid={`attribute-${attribute.key}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Icon className={`text-${color}-400 text-lg`} />
                  <span className="font-medium">{attribute.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-8 h-8 p-0 bg-destructive/20 text-destructive border-destructive/20 hover:bg-destructive/30"
                    onClick={() => handleAttributeChange(attribute.key, -1)}
                    disabled={attribute.value <= 0}
                    data-testid={`button-decrease-${attribute.key}`}
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="font-bold text-lg min-w-[3rem] text-center" data-testid={`value-${attribute.key}`}>
                    {attribute.value}
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-8 h-8 p-0 bg-primary/20 text-primary border-primary/20 hover:bg-primary/30"
                    onClick={() => handleAttributeChange(attribute.key, 1)}
                    data-testid={`button-increase-${attribute.key}`}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              <div className="w-full bg-secondary rounded-full h-2">
                <div 
                  className={`bg-gradient-to-r from-${color}-500 to-${color}-400 h-2 rounded-full transition-all duration-500`}
                  style={{ width: `${getAttributeProgress(attribute.value)}%` }}
                  data-testid={`progress-${attribute.key}`}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
