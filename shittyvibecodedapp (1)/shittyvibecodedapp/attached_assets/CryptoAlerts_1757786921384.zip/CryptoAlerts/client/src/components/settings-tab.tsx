import { useState } from "react";
import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useAdminMode } from "@/hooks/use-admin-mode";

interface SettingsTabProps {
  user: User;
}

export default function SettingsTab({ user }: SettingsTabProps) {
  const [settings, setSettings] = useState({
    telegramSync: true,
    notifications: false,
    darkMode: true,
    animations: true,
  });
  
  const [tapCount, setTapCount] = useState(0);
  const { isAdminMode, activateAdminMode, deactivateAdminMode } = useAdminMode();

  const handleVersionTap = () => {
    const newCount = tapCount + 1;
    setTapCount(newCount);
    
    if (newCount >= 10) {
      activateAdminMode();
      setTapCount(0);
    }
  };

  const handleSettingChange = (setting: string, value: boolean) => {
    setSettings(prev => ({ ...prev, [setting]: value }));
  };

  return (
    <div className="p-4" data-testid="settings-tab">
      <h2 className="text-xl font-bold mb-6">Settings</h2>
      
      <div className="space-y-4">
        {/* Profile Section */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-medium mb-3">Profile</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="telegram-sync" className="text-sm">Telegram Sync</Label>
              <Switch
                id="telegram-sync"
                checked={settings.telegramSync}
                onCheckedChange={(checked) => handleSettingChange("telegramSync", checked)}
                data-testid="switch-telegram-sync"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications" className="text-sm">Notifications</Label>
              <Switch
                id="notifications"
                checked={settings.notifications}
                onCheckedChange={(checked) => handleSettingChange("notifications", checked)}
                data-testid="switch-notifications"
              />
            </div>
          </div>
        </div>

        {/* Appearance */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-medium mb-3">Appearance</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="dark-mode" className="text-sm">Dark Mode</Label>
              <Switch
                id="dark-mode"
                checked={settings.darkMode}
                onCheckedChange={(checked) => handleSettingChange("darkMode", checked)}
                data-testid="switch-dark-mode"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="animations" className="text-sm">Animations</Label>
              <Switch
                id="animations"
                checked={settings.animations}
                onCheckedChange={(checked) => handleSettingChange("animations", checked)}
                data-testid="switch-animations"
              />
            </div>
          </div>
        </div>

        {/* Data */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-medium mb-3">Data</h3>
          <div className="space-y-3">
            <button className="w-full text-left text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="button-export-data">
              Export Data
            </button>
            <button className="w-full text-left text-sm text-muted-foreground hover:text-foreground transition-colors" data-testid="button-import-data">
              Import Data
            </button>
            <button className="w-full text-left text-sm text-destructive hover:text-destructive/80 transition-colors" data-testid="button-reset-progress">
              Reset All Progress
            </button>
          </div>
        </div>

        {/* About */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h3 className="font-medium mb-3">About</h3>
          <div className="space-y-2 text-sm text-muted-foreground">
            <div className="flex justify-between">
              <span>Version</span>
              <span 
                className="cursor-pointer"
                onClick={handleVersionTap}
                data-testid="version-tap-area"
              >
                1.0.0
              </span>
            </div>
            <div className="flex justify-between">
              <span>Developer</span>
              <span>QuestMaster Team</span>
            </div>
          </div>
        </div>

        {/* Admin Mode Indicator */}
        {isAdminMode && (
          <div className="bg-destructive/20 border border-destructive text-destructive rounded-lg p-4 text-center" data-testid="admin-mode-indicator">
            <h3 className="font-bold mb-2">⚡ Admin Mode Activated</h3>
            <p className="text-sm mb-3">Long-tap any element to edit. Access debug console in developer tools.</p>
            <Button
              variant="destructive"
              onClick={deactivateAdminMode}
              data-testid="button-deactivate-admin"
            >
              Deactivate Admin Mode
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
