import { useEffect, useState } from "react";
import { Crown } from "lucide-react";

interface LevelUpNotificationProps {
  isVisible: boolean;
  newLevel: number;
}

export default function LevelUpNotification({ isVisible, newLevel }: LevelUpNotificationProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (isVisible) {
      setShow(true);
      const timer = setTimeout(() => {
        setShow(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  if (!show) return null;

  return (
    <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50" data-testid="level-up-notification">
      <div className="bg-gradient-to-r from-primary to-accent p-6 rounded-xl text-center animate-level-up">
        <div className="text-white">
          <Crown className="w-12 h-12 mx-auto mb-2" />
          <h3 className="text-2xl font-bold font-gaming mb-1">LEVEL UP!</h3>
          <p className="text-lg">Level <span data-testid="new-level">{newLevel}</span></p>
        </div>
      </div>
    </div>
  );
}
