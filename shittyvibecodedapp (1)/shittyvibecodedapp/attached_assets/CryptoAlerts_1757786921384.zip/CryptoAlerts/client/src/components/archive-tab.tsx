import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ArchivedQuest } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { Undo2, Archive } from "lucide-react";

interface ArchiveTabProps {
  archivedQuests: ArchivedQuest[];
}

export default function ArchiveTab({ archivedQuests }: ArchiveTabProps) {
  const queryClient = useQueryClient();

  const undoQuest = useMutation({
    mutationFn: async (questId: string) => {
      return apiRequest("POST", `/api/archived-quests/${questId}/undo`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/archived-quests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
  });

  const getTimeRemaining = (expiresAt: Date) => {
    const now = new Date();
    const remaining = new Date(expiresAt).getTime() - now.getTime();
    if (remaining <= 0) return "Expired";
    
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((remaining % (1000 * 60)) / 1000);
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-4" data-testid="archive-tab">
      <h2 className="text-xl font-bold mb-6">Quest Archive</h2>
      
      {archivedQuests.length === 0 ? (
        <div className="text-center py-12" data-testid="empty-archive">
          <Archive className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Archived Quests</h3>
          <p className="text-muted-foreground">Completed quests will appear here for 24 hours.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {archivedQuests.map((quest) => (
            <div 
              key={quest.id} 
              className="bg-card border border-border rounded-lg p-4 opacity-75"
              data-testid={`archived-quest-${quest.id}`}
            >
              <div className="flex items-start gap-3">
                <div className={`rank-badge rank-${quest.rank.toLowerCase()} rounded-md w-8 h-8 flex items-center justify-center text-white font-bold text-sm opacity-60`}>
                  {quest.rank}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-foreground mb-1" data-testid={`archived-quest-name-${quest.id}`}>
                    {quest.name}
                  </h4>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-green-400">
                      Completed {formatDistanceToNow(new Date(quest.completedAt!), { addSuffix: true })}
                    </span>
                    <span className="text-destructive font-mono" data-testid={`quest-expires-${quest.id}`}>
                      Deletes in: {getTimeRemaining(quest.expiresAt)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-primary">+{quest.xpReward} XP earned</span>
                      {quest.attributeRewards && Object.entries(quest.attributeRewards).map(([attr, value]) => (
                        <span 
                          key={attr} 
                          className={`text-${getAttributeColor(attr)}-400`}
                          data-testid={`archived-quest-attribute-${quest.id}-${attr}`}
                        >
                          +{value} {attr.charAt(0).toUpperCase() + attr.slice(1)} earned
                        </span>
                      ))}
                    </div>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => undoQuest.mutate(quest.id)}
                      disabled={undoQuest.isPending}
                      className="text-xs"
                      data-testid={`button-undo-quest-${quest.id}`}
                    >
                      <Undo2 className="w-3 h-3 mr-1" />
                      {undoQuest.isPending ? "Undoing..." : "Undo"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function getAttributeColor(attribute: string): string {
  const colors = {
    physique: "red",
    mental: "purple",
    success: "yellow",
    social: "blue",
    skills: "green",
  };
  return colors[attribute as keyof typeof colors] || "gray";
}
