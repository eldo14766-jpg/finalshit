import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Note } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useCrypto } from "@/hooks/use-crypto";
import { formatDistanceToNow } from "date-fns";
import { Plus, StickyNote, Lock, Shield } from "lucide-react";

interface NotesTabProps {
  notes: Note[];
  userId: string;
}

export default function NotesTab({ notes, userId }: NotesTabProps) {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    isEncrypted: false,
    password: "",
  });

  const { encrypt, decrypt } = useCrypto();
  const queryClient = useQueryClient();

  const createNote = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/notes", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes", userId] });
      setIsCreateModalOpen(false);
      resetForm();
    },
  });

  const updateNote = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return apiRequest("PUT", `/api/notes/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes", userId] });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      isEncrypted: false,
      password: "",
    });
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    
    let noteData = {
      title: formData.title,
      content: formData.content,
      isEncrypted: formData.isEncrypted,
      encryptedData: null,
      userId,
    };

    if (formData.isEncrypted && formData.password) {
      const encryptedData = await encrypt(formData.content, formData.password);
      noteData = {
        ...noteData,
        content: "", // Clear plaintext content
        encryptedData,
      };
    }

    createNote.mutate(noteData);
  };

  const handleNoteClick = (note: Note) => {
    if (note.isEncrypted) {
      setSelectedNote(note);
      setIsPasswordModalOpen(true);
    } else {
      // Open note for viewing/editing
      setSelectedNote(note);
    }
  };

  const handlePasswordSubmit = async (password: string) => {
    if (!selectedNote || !selectedNote.encryptedData) return;

    try {
      const decryptedContent = await decrypt(selectedNote.encryptedData, password);
      // Create a temporary decrypted version for viewing
      setSelectedNote({
        ...selectedNote,
        content: decryptedContent,
      });
      setIsPasswordModalOpen(false);
    } catch (error) {
      alert("Incorrect password");
    }
  };

  return (
    <div className="p-4" data-testid="notes-tab">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Monarch's Journal</h2>
        <Button 
          onClick={() => setIsCreateModalOpen(true)}
          data-testid="button-new-note"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Note
        </Button>
      </div>

      {notes.length === 0 ? (
        <div className="text-center py-12" data-testid="empty-notes">
          <StickyNote className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Notes Yet</h3>
          <p className="text-muted-foreground mb-4">Start documenting your thoughts and ideas!</p>
          <Button onClick={() => setIsCreateModalOpen(true)}>
            Create First Note
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {notes.map((note) => (
            <div 
              key={note.id}
              className="bg-card border border-border rounded-lg p-4 hover:bg-card/80 transition-colors cursor-pointer"
              onClick={() => handleNoteClick(note)}
              data-testid={`note-${note.id}`}
            >
              <div className="flex items-start gap-3">
                {note.isEncrypted ? (
                  <Lock className="text-red-400 text-lg mt-1" />
                ) : (
                  <StickyNote className="text-yellow-400 text-lg mt-1" />
                )}
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-foreground mb-1" data-testid={`note-title-${note.id}`}>
                    {note.title}
                  </h4>
                  {note.isEncrypted ? (
                    <div className="text-sm text-muted-foreground mb-2 flex items-center gap-2">
                      <Shield className="text-red-400 w-4 h-4" />
                      <span>This note is password protected</span>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-2" data-testid={`note-preview-${note.id}`}>
                      {note.content.substring(0, 100)}...
                    </p>
                  )}
                  <div className="text-xs text-muted-foreground">
                    Last edited: {formatDistanceToNow(new Date(note.updatedAt!), { addSuffix: true })}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Note Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent data-testid="create-note-modal">
          <DialogHeader>
            <DialogTitle>Create New Note</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleCreateNote} className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Note title"
                required
                data-testid="input-note-title"
              />
            </div>

            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                value={formData.content}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Write your note here..."
                className="h-32 resize-none"
                required
                data-testid="input-note-content"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="encrypt"
                checked={formData.isEncrypted}
                onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isEncrypted: checked }))}
                data-testid="switch-encrypt-note"
              />
              <Label htmlFor="encrypt" className="flex items-center gap-2">
                <Lock className="w-4 h-4" />
                Encrypt note with password
              </Label>
            </div>

            {formData.isEncrypted && (
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="Enter password for encryption"
                  required={formData.isEncrypted}
                  data-testid="input-note-password"
                />
              </div>
            )}

            <div className="flex gap-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setIsCreateModalOpen(false)}
                className="flex-1"
                data-testid="button-cancel-note"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1"
                disabled={createNote.isPending}
                data-testid="button-save-note"
              >
                {createNote.isPending ? "Saving..." : "Save Note"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Password Modal */}
      <Dialog open={isPasswordModalOpen} onOpenChange={setIsPasswordModalOpen}>
        <DialogContent className="max-w-sm" data-testid="password-modal">
          <DialogHeader className="text-center">
            <Lock className="text-destructive text-3xl mx-auto mb-3" />
            <DialogTitle>Protected Note</DialogTitle>
            <p className="text-sm text-muted-foreground">Enter password to view this note</p>
          </DialogHeader>
          
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              const password = (e.target as HTMLFormElement).password.value;
              handlePasswordSubmit(password);
            }}
            className="space-y-4"
          >
            <Input
              name="password"
              type="password"
              placeholder="Enter password"
              className="text-center"
              autoFocus
              data-testid="input-unlock-password"
            />
            
            <div className="flex gap-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setIsPasswordModalOpen(false)}
                className="flex-1"
                data-testid="button-cancel-unlock"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1"
                data-testid="button-unlock-note"
              >
                Unlock
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* View Note Modal */}
      {selectedNote && !selectedNote.isEncrypted && (
        <Dialog open={!!selectedNote} onOpenChange={() => setSelectedNote(null)}>
          <DialogContent data-testid="view-note-modal">
            <DialogHeader>
              <DialogTitle>{selectedNote.title}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="bg-muted/50 rounded-lg p-4 max-h-64 overflow-y-auto">
                <p className="whitespace-pre-wrap" data-testid="note-content">
                  {selectedNote.content}
                </p>
              </div>
              
              <div className="text-xs text-muted-foreground">
                Created: {formatDistanceToNow(new Date(selectedNote.createdAt!), { addSuffix: true })}
                <br />
                Last edited: {formatDistanceToNow(new Date(selectedNote.updatedAt!), { addSuffix: true })}
              </div>
              
              <Button
                onClick={() => setSelectedNote(null)}
                className="w-full"
                data-testid="button-close-note"
              >
                Close
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
