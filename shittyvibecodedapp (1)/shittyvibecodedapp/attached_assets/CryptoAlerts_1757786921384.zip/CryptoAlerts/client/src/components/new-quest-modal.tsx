import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { QuestGroup, QuestRanks, AttributeTypes } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { X } from "lucide-react";

interface NewQuestModalProps {
  isOpen: boolean;
  onClose: () => void;
  questGroups: QuestGroup[];
  userId: string;
}

interface QuestFormData {
  name: string;
  description: string;
  groupId: string;
  rank: string;
  xpReward: number;
  attributePoints: number;
  selectedAttributes: Record<string, boolean>;
  attributeDistribution: Record<string, number>;
  deadline: string;
  repeatType: string;
}

export default function NewQuestModal({ isOpen, onClose, questGroups, userId }: NewQuestModalProps) {
  const [formData, setFormData] = useState<QuestFormData>({
    name: "",
    description: "",
    groupId: "",
    rank: "C",
    xpReward: 50,
    attributePoints: 1,
    selectedAttributes: {},
    attributeDistribution: {},
    deadline: "",
    repeatType: "",
  });

  const queryClient = useQueryClient();

  const createQuest = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/quests", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests", userId] });
      onClose();
      resetForm();
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      groupId: "",
      rank: "C",
      xpReward: 50,
      attributePoints: 1,
      selectedAttributes: {},
      attributeDistribution: {},
      deadline: "",
      repeatType: "",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Calculate attribute rewards
    const selectedAttrs = Object.keys(formData.selectedAttributes).filter(
      attr => formData.selectedAttributes[attr]
    );
    
    const attributeRewards: Record<string, number> = {};
    if (selectedAttrs.length > 0) {
      const pointsPerAttribute = formData.attributePoints / selectedAttrs.length;
      selectedAttrs.forEach(attr => {
        attributeRewards[attr] = Math.round(pointsPerAttribute * 100) / 100;
      });
    }

    const questData = {
      name: formData.name,
      description: formData.description || null,
      groupId: formData.groupId || null,
      rank: formData.rank,
      xpReward: formData.xpReward,
      attributeRewards: Object.keys(attributeRewards).length > 0 ? attributeRewards : null,
      deadline: formData.deadline ? new Date(formData.deadline) : null,
      repeatType: formData.repeatType || null,
      isCompleted: false,
      userId,
    };

    createQuest.mutate(questData);
  };

  const handleAttributeChange = (attribute: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      selectedAttributes: {
        ...prev.selectedAttributes,
        [attribute]: checked,
      },
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" data-testid="new-quest-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Create New Quest
            <button onClick={onClose} data-testid="button-close-modal">
              <X className="h-4 w-4" />
            </button>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Quest Name */}
          <div>
            <Label htmlFor="name">Quest Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter quest name"
              required
              data-testid="input-quest-name"
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Quest description (optional)"
              className="h-20 resize-none"
              data-testid="input-quest-description"
            />
          </div>

          {/* Group Selection */}
          <div>
            <Label>Group</Label>
            <Select value={formData.groupId} onValueChange={(value) => setFormData(prev => ({ ...prev, groupId: value }))}>
              <SelectTrigger data-testid="select-quest-group">
                <SelectValue placeholder="Select or create group..." />
              </SelectTrigger>
              <SelectContent>
                {questGroups.map((group) => (
                  <SelectItem key={group.id} value={group.id}>
                    {group.icon} {group.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Rank Selection */}
          <div>
            <Label>Difficulty Rank</Label>
            <div className="grid grid-cols-4 gap-2">
              {QuestRanks.map((rank) => (
                <button
                  key={rank}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, rank }))}
                  className={`rank-badge rank-${rank.toLowerCase()} rounded-lg py-2 font-bold text-white hover:scale-105 transition-transform ${
                    formData.rank === rank ? "ring-2 ring-white ring-offset-2 ring-offset-background" : ""
                  }`}
                  data-testid={`rank-button-${rank}`}
                >
                  {rank}
                </button>
              ))}
            </div>
          </div>

          {/* Rewards Section */}
          <div className="border border-border rounded-lg p-4">
            <h4 className="font-medium mb-3">Rewards</h4>
            
            {/* XP Reward */}
            <div className="mb-4">
              <Label htmlFor="xpReward">XP Reward</Label>
              <Input
                id="xpReward"
                type="number"
                value={formData.xpReward}
                onChange={(e) => setFormData(prev => ({ ...prev, xpReward: parseInt(e.target.value) || 0 }))}
                min="1"
                max="1000"
                data-testid="input-xp-reward"
              />
            </div>

            {/* Attribute Points */}
            <div>
              <Label htmlFor="attributePoints">Attribute Points</Label>
              <div className="flex items-center gap-2 mb-2">
                <Input
                  id="attributePoints"
                  type="number"
                  value={formData.attributePoints}
                  onChange={(e) => setFormData(prev => ({ ...prev, attributePoints: parseInt(e.target.value) || 0 }))}
                  min="1"
                  max="10"
                  className="w-20"
                  data-testid="input-attribute-points"
                />
                <span className="text-sm text-muted-foreground">points to distribute</span>
              </div>
              
              {/* Attribute Selection */}
              <div className="space-y-2">
                {AttributeTypes.map((attribute) => (
                  <label key={attribute} className="flex items-center gap-2 cursor-pointer">
                    <Checkbox
                      checked={formData.selectedAttributes[attribute] || false}
                      onCheckedChange={(checked) => handleAttributeChange(attribute, checked as boolean)}
                      data-testid={`checkbox-attribute-${attribute}`}
                    />
                    <span className="text-sm capitalize">{attribute}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Schedule Settings */}
          <div className="border border-border rounded-lg p-4">
            <h4 className="font-medium mb-3">Schedule (Optional)</h4>
            
            <div className="space-y-2">
              <div>
                <Label>Deadline</Label>
                <Input
                  type="datetime-local"
                  value={formData.deadline}
                  onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
                  data-testid="input-quest-deadline"
                />
              </div>
              
              <div>
                <Label>Repeat Type</Label>
                <Select value={formData.repeatType} onValueChange={(value) => setFormData(prev => ({ ...prev, repeatType: value }))}>
                  <SelectTrigger data-testid="select-repeat-type">
                    <SelectValue placeholder="No repeat" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No repeat</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              className="flex-1"
              data-testid="button-cancel-quest"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={!formData.name || createQuest.isPending}
              data-testid="button-create-quest"
            >
              {createQuest.isPending ? "Creating..." : "Create Quest"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
