import { useEffect, useRef } from "react";

interface RadarChartData {
  name: string;
  value: number;
}

interface RadarChartProps {
  data: RadarChartData[];
  width?: number;
  height?: number;
}

export default function RadarChart({ data, width = 280, height = 280 }: RadarChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas size
    canvas.width = width;
    canvas.height = height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) / 2 - 40;
    const levels = 5;
    const maxValue = Math.max(...data.map(d => d.value), 100);

    // Draw grid lines
    ctx.strokeStyle = "#374151";
    ctx.lineWidth = 1;

    for (let level = 1; level <= levels; level++) {
      ctx.beginPath();
      const levelRadius = (radius * level) / levels;
      
      for (let i = 0; i < data.length; i++) {
        const angle = (Math.PI * 2 * i) / data.length - Math.PI / 2;
        const x = centerX + Math.cos(angle) * levelRadius;
        const y = centerY + Math.sin(angle) * levelRadius;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.closePath();
      ctx.stroke();
    }

    // Draw axis lines
    for (let i = 0; i < data.length; i++) {
      const angle = (Math.PI * 2 * i) / data.length - Math.PI / 2;
      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x, y);
      ctx.stroke();
    }

    // Draw data area
    ctx.fillStyle = "rgba(147, 51, 234, 0.2)"; // Purple with transparency
    ctx.strokeStyle = "rgb(147, 51, 234)";
    ctx.lineWidth = 2;

    ctx.beginPath();
    for (let i = 0; i < data.length; i++) {
      const angle = (Math.PI * 2 * i) / data.length - Math.PI / 2;
      const valueRadius = (radius * data[i].value) / maxValue;
      const x = centerX + Math.cos(angle) * valueRadius;
      const y = centerY + Math.sin(angle) * valueRadius;
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Draw data points
    ctx.fillStyle = "rgb(147, 51, 234)";
    for (let i = 0; i < data.length; i++) {
      const angle = (Math.PI * 2 * i) / data.length - Math.PI / 2;
      const valueRadius = (radius * data[i].value) / maxValue;
      const x = centerX + Math.cos(angle) * valueRadius;
      const y = centerY + Math.sin(angle) * valueRadius;
      
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw labels
    ctx.fillStyle = "#f3f4f6";
    ctx.font = "12px Inter";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    for (let i = 0; i < data.length; i++) {
      const angle = (Math.PI * 2 * i) / data.length - Math.PI / 2;
      const labelRadius = radius + 20;
      const x = centerX + Math.cos(angle) * labelRadius;
      const y = centerY + Math.sin(angle) * labelRadius;
      
      ctx.fillText(data[i].name, x, y);
    }

  }, [data, width, height]);

  return (
    <canvas 
      ref={canvasRef} 
      className="max-w-full h-auto"
      data-testid="radar-chart"
    />
  );
}
