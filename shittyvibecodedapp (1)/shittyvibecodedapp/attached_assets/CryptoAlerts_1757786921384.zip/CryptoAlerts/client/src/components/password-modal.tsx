import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";

interface PasswordModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  onSubmit?: (password: string) => void;
}

export default function PasswordModal({ isOpen = false, onClose, onSubmit }: PasswordModalProps) {
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSubmit) {
      onSubmit(password);
    }
    setPassword("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm" data-testid="password-modal">
        <DialogHeader className="text-center">
          <Lock className="text-destructive text-3xl mx-auto mb-3" />
          <DialogTitle>Protected Note</DialogTitle>
          <p className="text-sm text-muted-foreground">Enter password to view this note</p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            className="text-center"
            autoFocus
            data-testid="input-password"
          />
          
          <div className="flex gap-3">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              className="flex-1"
              data-testid="button-cancel-password"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              data-testid="button-submit-password"
            >
              Unlock
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
