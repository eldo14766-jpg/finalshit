import { Quest } from "@shared/schema";
import { CheckCircle, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface QuestCardProps {
  quest: Quest;
  onComplete: () => void;
  onDelete?: () => void;
  isCompleting?: boolean;
}

export default function QuestCard({ quest, onComplete, onDelete, isCompleting }: QuestCardProps) {
  const getDeadlineProgress = () => {
    if (!quest.deadline) return 0;
    const now = new Date();
    const deadline = new Date(quest.deadline);
    const created = new Date(quest.createdAt!);
    const totalTime = deadline.getTime() - created.getTime();
    const remainingTime = deadline.getTime() - now.getTime();
    return Math.max(0, Math.min(100, (remainingTime / totalTime) * 100));
  };

  const deadlineProgress = getDeadlineProgress();
  const isOverdue = quest.deadline && new Date(quest.deadline) < new Date();

  const getProgressColor = () => {
    if (deadlineProgress > 50) return "from-green-500 to-green-400";
    if (deadlineProgress > 25) return "from-yellow-500 to-orange-400";
    return "from-orange-500 to-red-500";
  };

  return (
    <div className="quest-card bg-card border border-border rounded-lg p-4 relative overflow-hidden" data-testid={`quest-card-${quest.id}`}>
      <div className="flex items-start gap-3">
        <div className={`rank-badge rank-${quest.rank.toLowerCase()} rounded-md w-8 h-8 flex items-center justify-center text-white font-bold text-sm`}>
          {quest.rank}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-foreground mb-1" data-testid={`quest-name-${quest.id}`}>
            {quest.name}
          </h4>
          {quest.description && (
            <p className="text-sm text-muted-foreground mb-2" data-testid={`quest-description-${quest.id}`}>
              {quest.description}
            </p>
          )}
          
          {/* Deadline Progress */}
          {quest.deadline && (
            <div className="w-full bg-secondary rounded-full h-1.5 mb-2">
              <div 
                className={`bg-gradient-to-r ${getProgressColor()} h-1.5 rounded-full transition-all duration-300`}
                style={{ width: `${deadlineProgress}%` }}
                data-testid={`quest-deadline-progress-${quest.id}`}
              />
            </div>
          )}
          
          <div className="flex items-center justify-between text-xs">
            <span className={`${isOverdue ? 'text-red-400' : 'text-muted-foreground'}`}>
              {quest.deadline ? (
                isOverdue ? 
                  `Overdue ${formatDistanceToNow(new Date(quest.deadline), { addSuffix: true })}` :
                  `Due ${formatDistanceToNow(new Date(quest.deadline), { addSuffix: true })}`
              ) : quest.repeatType ? (
                `Repeats: ${quest.repeatType}`
              ) : (
                "One-time quest"
              )}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-primary font-medium" data-testid={`quest-xp-${quest.id}`}>
                +{quest.xpReward} XP
              </span>
              {quest.attributeRewards && Object.entries(quest.attributeRewards).map(([attr, value]) => (
                <span 
                  key={attr} 
                  className={`text-${getAttributeColor(attr)}-400`}
                  data-testid={`quest-attribute-${quest.id}-${attr}`}
                >
                  +{value} {attr.charAt(0).toUpperCase() + attr.slice(1)}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2 mt-3">
        <button
          onClick={onComplete}
          disabled={isCompleting}
          className="flex-1 bg-primary hover:bg-primary/90 disabled:opacity-50 text-primary-foreground py-2 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
          data-testid={`button-complete-quest-${quest.id}`}
        >
          <CheckCircle className="w-4 h-4" />
          {isCompleting ? "Completing..." : "Complete"}
        </button>
        {onDelete && (
          <button
            onClick={onDelete}
            className="bg-destructive/20 hover:bg-destructive/30 text-destructive py-2 px-4 rounded-lg flex items-center justify-center transition-colors"
            data-testid={`button-delete-quest-${quest.id}`}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}

function getAttributeColor(attribute: string): string {
  const colors = {
    physique: "red",
    mental: "purple",
    success: "yellow",
    social: "blue",
    skills: "green",
  };
  return colors[attribute as keyof typeof colors] || "gray";
}
