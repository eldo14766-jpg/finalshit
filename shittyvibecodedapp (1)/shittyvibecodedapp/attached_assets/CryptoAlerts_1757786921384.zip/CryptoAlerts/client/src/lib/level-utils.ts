import { GlobalRank } from "@shared/schema";

export function calculateLevel(totalXP: number): number {
  return Math.floor(totalXP / 800) + 1;
}

export function calculateCurrentXP(totalXP: number): number {
  return totalXP % 800;
}

export function calculateGlobalRank(level: number): GlobalRank {
  if (level >= 401) return "SSS";
  if (level >= 251) return "SS";
  if (level >= 151) return "S";
  if (level >= 101) return "A";
  if (level >= 61) return "B";
  if (level >= 31) return "C";
  if (level >= 11) return "D";
  return "E";
}

export function getXPToNextLevel(currentXP: number): number {
  return 800 - currentXP;
}

export function getLevelProgress(currentXP: number): number {
  return (currentXP / 800) * 100;
}

export function getRankRange(rank: GlobalRank): { min: number; max: number } {
  const ranges = {
    E: { min: 1, max: 10 },
    D: { min: 11, max: 30 },
    C: { min: 31, max: 60 },
    B: { min: 61, max: 100 },
    A: { min: 101, max: 150 },
    S: { min: 151, max: 250 },
    SS: { min: 251, max: 400 },
    SSS: { min: 401, max: Infinity },
  };
  return ranges[rank] || ranges.E;
}
