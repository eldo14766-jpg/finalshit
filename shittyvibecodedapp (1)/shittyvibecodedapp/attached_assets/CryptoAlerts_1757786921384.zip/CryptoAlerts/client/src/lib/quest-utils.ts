import { QuestRank } from "@shared/schema";

export function getRankColor(rank: QuestRank): string {
  const colors = {
    E: "from-gray-500 to-gray-400",
    D: "from-gray-600 to-gray-500", 
    C: "from-green-500 to-green-400",
    B: "from-blue-500 to-blue-400",
    A: "from-orange-500 to-orange-400",
    S: "from-purple-500 to-purple-400",
    SS: "from-pink-500 to-red-400",
    SSS: "from-red-500 to-yellow-400",
  };
  return colors[rank] || colors.C;
}

export function getRankMultiplier(rank: QuestRank): number {
  const multipliers = {
    E: 0.5,
    D: 0.75,
    C: 1.0,
    B: 1.25,
    A: 1.5,
    S: 2.0,
    SS: 3.0,
    SSS: 5.0,
  };
  return multipliers[rank] || 1.0;
}

export function suggestRewards(rank: QuestRank): { xp: number; attributes: number } {
  const base = {
    E: { xp: 25, attributes: 1 },
    D: { xp: 40, attributes: 1 },
    C: { xp: 60, attributes: 2 },
    B: { xp: 90, attributes: 3 },
    A: { xp: 130, attributes: 4 },
    S: { xp: 200, attributes: 6 },
    SS: { xp: 300, attributes: 8 },
    SSS: { xp: 500, attributes: 12 },
  };
  return base[rank] || base.C;
}
