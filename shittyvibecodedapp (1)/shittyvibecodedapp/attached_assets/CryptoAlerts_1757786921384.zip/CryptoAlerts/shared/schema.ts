import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  level: integer("level").notNull().default(1),
  totalXP: integer("total_xp").notNull().default(0),
  currentXP: integer("current_xp").notNull().default(0),
  globalRank: text("global_rank").notNull().default("E"),
  physique: integer("physique").notNull().default(0),
  mental: integer("mental").notNull().default(0),
  success: integer("success").notNull().default(0),
  social: integer("social").notNull().default(0),
  skills: integer("skills").notNull().default(0),
  adminMode: boolean("admin_mode").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const questGroups = pgTable("quest_groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
});

export const quests = pgTable("quests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  groupId: varchar("group_id").references(() => questGroups.id),
  rank: text("rank").notNull(), // E, D, C, B, A, S, SS, SSS
  xpReward: integer("xp_reward").notNull(),
  attributeRewards: jsonb("attribute_rewards").$type<{
    physique?: number;
    mental?: number;
    success?: number;
    social?: number;
    skills?: number;
  }>(),
  deadline: timestamp("deadline"),
  repeatType: text("repeat_type"), // daily, weekly, custom
  isCompleted: boolean("is_completed").notNull().default(false),
  userId: varchar("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const archivedQuests = pgTable("archived_quests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  originalQuestId: varchar("original_quest_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  rank: text("rank").notNull(),
  xpReward: integer("xp_reward").notNull(),
  attributeRewards: jsonb("attribute_rewards").$type<{
    physique?: number;
    mental?: number;
    success?: number;
    social?: number;
    skills?: number;
  }>(),
  completedAt: timestamp("completed_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
});

export const notes = pgTable("notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isEncrypted: boolean("is_encrypted").notNull().default(false),
  encryptedData: text("encrypted_data"), // encrypted content + salt
  userId: varchar("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
}).partial({ id: true });

export const insertQuestGroupSchema = createInsertSchema(questGroups).omit({
  id: true,
});

export const insertQuestSchema = createInsertSchema(quests).omit({
  id: true,
  createdAt: true,
});

export const insertArchivedQuestSchema = createInsertSchema(archivedQuests).omit({
  id: true,
  completedAt: true,
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertQuestGroup = z.infer<typeof insertQuestGroupSchema>;
export type QuestGroup = typeof questGroups.$inferSelect;

export type InsertQuest = z.infer<typeof insertQuestSchema>;
export type Quest = typeof quests.$inferSelect;

export type InsertArchivedQuest = z.infer<typeof insertArchivedQuestSchema>;
export type ArchivedQuest = typeof archivedQuests.$inferSelect;

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;

// Enums and constants
export const QuestRanks = ["E", "D", "C", "B", "A", "S", "SS", "SSS"] as const;
export type QuestRank = typeof QuestRanks[number];

export const AttributeTypes = ["physique", "mental", "success", "social", "skills"] as const;
export type AttributeType = typeof AttributeTypes[number];

export const GlobalRanks = ["E", "D", "C", "B", "A", "S", "SS", "SSS"] as const;
export type GlobalRank = typeof GlobalRanks[number];
